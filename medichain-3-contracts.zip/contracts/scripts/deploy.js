const { ethers } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();

  console.log("Deploying MediChain with account:", deployer.address);
  console.log("Account balance:", ethers.formatEther(await deployer.provider.getBalance(deployer.address)), "ETH");

  const MediChain = await ethers.getContractFactory("MediChain");
  console.log("Deploying contract...");

  const medichain = await MediChain.deploy();
  await medichain.waitForDeployment();

  const address = await medichain.getAddress();
  console.log("✅ MediChain deployed to:", address);
  console.log("Transaction hash:", medichain.deploymentTransaction()?.hash);

  // Write the address to a JSON file for the frontend/backend
  const fs = require("fs");
  const path = require("path");

  const deployment = {
    contractAddress: address,
    network: (await ethers.provider.getNetwork()).name,
    chainId: Number((await ethers.provider.getNetwork()).chainId),
    deployedAt: new Date().toISOString(),
    deployer: deployer.address,
  };

  const outPath = path.join(__dirname, "..", "deployment.json");
  fs.writeFileSync(outPath, JSON.stringify(deployment, null, 2));
  console.log("Deployment info written to contracts/deployment.json");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
