const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("MediChain", function () {
  let medichain;
  let owner, patient1, doctor1, other;

  beforeEach(async () => {
    [owner, patient1, doctor1, other] = await ethers.getSigners();

    const MediChain = await ethers.getContractFactory("MediChain");
    medichain = await MediChain.deploy();
    await medichain.waitForDeployment();
  });

  describe("Deployment", function () {
    it("Sets the owner correctly", async () => {
      expect(await medichain.owner()).to.equal(owner.address);
    });

    it("Starts with zero records", async () => {
      expect(await medichain.recordCount()).to.equal(0);
    });
  });

  describe("Patient Registration", function () {
    it("Allows a user to register as patient", async () => {
      await medichain.connect(patient1).registerPatient("Alice Smith", "O+");
      const p = await medichain.patients(patient1.address);
      expect(p.registered).to.be.true;
      expect(p.name).to.equal("Alice Smith");
      expect(p.bloodGroup).to.equal("O+");
    });

    it("Emits PatientRegistered event", async () => {
      await expect(medichain.connect(patient1).registerPatient("Alice Smith", "O+"))
        .to.emit(medichain, "PatientRegistered")
        .withArgs(patient1.address, "Alice Smith", await latestTimestamp());
    });

    it("Prevents double registration", async () => {
      await medichain.connect(patient1).registerPatient("Alice Smith", "O+");
      await expect(
        medichain.connect(patient1).registerPatient("Alice Again", "B+")
      ).to.be.revertedWith("MediChain: already registered as patient");
    });
  });

  describe("Doctor Registration", function () {
    it("Allows a user to register as doctor", async () => {
      await medichain.connect(doctor1).registerDoctor("Dr. Bob", "Cardiology", "LIC-001");
      const d = await medichain.doctors(doctor1.address);
      expect(d.registered).to.be.true;
      expect(d.verified).to.be.false;
    });

    it("Owner can verify a doctor", async () => {
      await medichain.connect(doctor1).registerDoctor("Dr. Bob", "Cardiology", "LIC-001");
      await medichain.connect(owner).verifyDoctor(doctor1.address);
      const d = await medichain.doctors(doctor1.address);
      expect(d.verified).to.be.true;
    });

    it("Non-owner cannot verify a doctor", async () => {
      await medichain.connect(doctor1).registerDoctor("Dr. Bob", "Cardiology", "LIC-001");
      await expect(
        medichain.connect(other).verifyDoctor(doctor1.address)
      ).to.be.revertedWith("MediChain: caller is not the owner");
    });
  });

  describe("Medical Records", function () {
    beforeEach(async () => {
      await medichain.connect(patient1).registerPatient("Alice Smith", "O+");
      await medichain.connect(doctor1).registerDoctor("Dr. Bob", "Cardiology", "LIC-001");
    });

    it("Patient can upload a record", async () => {
      const tx = await medichain
        .connect(patient1)
        .uploadRecord(
          "QmTestCID123",
          "abc123hash",
          "lab_report",
          "Blood Test Results"
        );
      const receipt = await tx.wait();
      expect(await medichain.recordCount()).to.equal(1);
    });

    it("Emits RecordUploaded event", async () => {
      await expect(
        medichain
          .connect(patient1)
          .uploadRecord("QmTestCID123", "abc123hash", "lab_report", "Blood Test")
      ).to.emit(medichain, "RecordUploaded");
    });

    it("Non-patient cannot upload records", async () => {
      await expect(
        medichain
          .connect(other)
          .uploadRecord("QmTestCID123", "abc123hash", "lab_report", "Test")
      ).to.be.revertedWith("MediChain: caller is not a registered patient");
    });

    it("Returns correct record data", async () => {
      await medichain
        .connect(patient1)
        .uploadRecord("QmTestCID123", "abc123hash", "lab_report", "Blood Test");

      const record = await medichain.getRecord(1);
      expect(record.ipfsCid).to.equal("QmTestCID123");
      expect(record.fileHash).to.equal("abc123hash");
      expect(record.patient).to.equal(patient1.address);
    });
  });

  describe("Permissions", function () {
    beforeEach(async () => {
      await medichain.connect(patient1).registerPatient("Alice Smith", "O+");
      await medichain.connect(doctor1).registerDoctor("Dr. Bob", "Cardiology", "LIC-001");
      await medichain
        .connect(patient1)
        .uploadRecord("QmTestCID123", "abc123hash", "lab_report", "Blood Test");
    });

    it("Patient can grant access to doctor", async () => {
      await medichain.connect(patient1).grantAccess(doctor1.address, 1);
      expect(await medichain.hasAccess(patient1.address, doctor1.address, 1)).to.be.true;
    });

    it("Emits AccessGranted event", async () => {
      await expect(medichain.connect(patient1).grantAccess(doctor1.address, 1))
        .to.emit(medichain, "AccessGranted")
        .withArgs(patient1.address, doctor1.address, 1, await latestTimestamp());
    });

    it("Patient can revoke access from doctor", async () => {
      await medichain.connect(patient1).grantAccess(doctor1.address, 1);
      await medichain.connect(patient1).revokeAccess(doctor1.address, 1);
      expect(await medichain.hasAccess(patient1.address, doctor1.address, 1)).to.be.false;
    });

    it("Emits AccessRevoked event", async () => {
      await medichain.connect(patient1).grantAccess(doctor1.address, 1);
      await expect(medichain.connect(patient1).revokeAccess(doctor1.address, 1))
        .to.emit(medichain, "AccessRevoked")
        .withArgs(patient1.address, doctor1.address, 1, await latestTimestamp());
    });

    it("Doctor without permission cannot access record", async () => {
      await expect(
        medichain.connect(doctor1).accessRecord(patient1.address, 1)
      ).to.be.revertedWith("MediChain: no access permission");
    });

    it("Doctor with permission can access record", async () => {
      await medichain.connect(patient1).grantAccess(doctor1.address, 1);
      await expect(medichain.connect(doctor1).accessRecord(patient1.address, 1))
        .to.emit(medichain, "RecordAccessed");
    });

    it("Cannot grant access to non-existent record", async () => {
      await expect(
        medichain.connect(patient1).grantAccess(doctor1.address, 999)
      ).to.be.revertedWith("MediChain: record does not exist");
    });
  });

  describe("Audit Log", function () {
    it("Logs all patient registration", async () => {
      await medichain.connect(patient1).registerPatient("Alice", "O+");
      expect(await medichain.getAuditLogLength()).to.equal(1);
    });

    it("Logs record upload", async () => {
      await medichain.connect(patient1).registerPatient("Alice", "O+");
      await medichain.connect(patient1).uploadRecord("QmCID", "hash", "lab_report", "Test");
      expect(await medichain.getAuditLogLength()).to.equal(2);
    });
  });
});

async function latestTimestamp() {
  const block = await ethers.provider.getBlock("latest");
  return block?.timestamp ?? 0;
}
