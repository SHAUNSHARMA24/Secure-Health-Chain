// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title MediChain
 * @author MediChain Team
 * @notice Decentralized medical record system — stores IPFS hashes, metadata,
 *         permissions, and audit logs on-chain. All sensitive data is kept
 *         off-chain (encrypted on IPFS); only cryptographic proofs live here.
 * @dev Compatible with Hardhat + Ethers.js v6
 */
contract MediChain {
    // ─── Structs ──────────────────────────────────────────────────────────────

    struct Patient {
        address wallet;
        string name;
        string bloodGroup;
        bool registered;
        uint256 registeredAt;
    }

    struct Doctor {
        address wallet;
        string name;
        string specialization;
        string licenseNumber;
        bool registered;
        bool verified;
        uint256 registeredAt;
    }

    struct MedicalRecord {
        uint256 id;
        address patient;
        string ipfsCid;        // Encrypted file CID on IPFS
        string fileHash;       // SHA-256 hash of the original (encrypted) file
        string recordType;     // "lab_report" | "prescription" | "diagnosis" etc.
        string title;
        uint256 timestamp;
        bool exists;
    }

    struct AuditEntry {
        address actor;
        address target;
        string action;
        uint256 entityId;
        uint256 timestamp;
    }

    // ─── State ────────────────────────────────────────────────────────────────

    address public owner;

    mapping(address => Patient) public patients;
    mapping(address => Doctor) public doctors;

    // recordId => MedicalRecord
    mapping(uint256 => MedicalRecord) public records;
    uint256 public recordCount;

    // patientAddress => array of recordIds
    mapping(address => uint256[]) public patientRecords;

    // keccak256(patientAddress, doctorAddress, recordId) => isGranted
    mapping(bytes32 => bool) public permissions;

    // All audit entries
    AuditEntry[] public auditLog;

    // ─── Events ───────────────────────────────────────────────────────────────

    event PatientRegistered(address indexed patient, string name, uint256 timestamp);
    event DoctorRegistered(address indexed doctor, string name, string specialization, uint256 timestamp);
    event DoctorVerified(address indexed doctor, uint256 timestamp);

    event RecordUploaded(
        uint256 indexed recordId,
        address indexed patient,
        string ipfsCid,
        string fileHash,
        string recordType,
        uint256 timestamp
    );

    event AccessGranted(
        address indexed patient,
        address indexed doctor,
        uint256 indexed recordId,
        uint256 timestamp
    );

    event AccessRevoked(
        address indexed patient,
        address indexed doctor,
        uint256 indexed recordId,
        uint256 timestamp
    );

    event RecordAccessed(
        address indexed doctor,
        address indexed patient,
        uint256 indexed recordId,
        uint256 timestamp
    );

    event AuditLogged(
        address indexed actor,
        string action,
        uint256 entityId,
        uint256 timestamp
    );

    // ─── Modifiers ────────────────────────────────────────────────────────────

    modifier onlyOwner() {
        require(msg.sender == owner, "MediChain: caller is not the owner");
        _;
    }

    modifier onlyRegisteredPatient() {
        require(patients[msg.sender].registered, "MediChain: caller is not a registered patient");
        _;
    }

    modifier onlyRegisteredDoctor() {
        require(doctors[msg.sender].registered, "MediChain: caller is not a registered doctor");
        _;
    }

    modifier recordExists(uint256 recordId) {
        require(records[recordId].exists, "MediChain: record does not exist");
        _;
    }

    // ─── Constructor ──────────────────────────────────────────────────────────

    constructor() {
        owner = msg.sender;
    }

    // ─── Patient functions ────────────────────────────────────────────────────

    /**
     * @notice Register as a patient
     * @param name Patient's full name
     * @param bloodGroup Patient's blood group (e.g. "O+")
     */
    function registerPatient(string calldata name, string calldata bloodGroup) external {
        require(!patients[msg.sender].registered, "MediChain: already registered as patient");
        require(bytes(name).length > 0, "MediChain: name cannot be empty");

        patients[msg.sender] = Patient({
            wallet: msg.sender,
            name: name,
            bloodGroup: bloodGroup,
            registered: true,
            registeredAt: block.timestamp
        });

        _logAudit(msg.sender, address(0), "patient_registered", 0);
        emit PatientRegistered(msg.sender, name, block.timestamp);
    }

    /**
     * @notice Upload a medical record's metadata to the blockchain
     * @param ipfsCid IPFS CID of the encrypted file
     * @param fileHash SHA-256 hash of the encrypted file
     * @param recordType Type of record (lab_report, prescription, etc.)
     * @param title Human-readable title
     */
    function uploadRecord(
        string calldata ipfsCid,
        string calldata fileHash,
        string calldata recordType,
        string calldata title
    ) external onlyRegisteredPatient returns (uint256) {
        require(bytes(ipfsCid).length > 0, "MediChain: CID cannot be empty");
        require(bytes(fileHash).length > 0, "MediChain: fileHash cannot be empty");

        recordCount++;
        uint256 newId = recordCount;

        records[newId] = MedicalRecord({
            id: newId,
            patient: msg.sender,
            ipfsCid: ipfsCid,
            fileHash: fileHash,
            recordType: recordType,
            title: title,
            timestamp: block.timestamp,
            exists: true
        });

        patientRecords[msg.sender].push(newId);

        _logAudit(msg.sender, address(0), "record_uploaded", newId);
        emit RecordUploaded(newId, msg.sender, ipfsCid, fileHash, recordType, block.timestamp);

        return newId;
    }

    /**
     * @notice Grant a doctor access to a specific record
     * @param doctor Doctor's wallet address
     * @param recordId ID of the record to share
     */
    function grantAccess(address doctor, uint256 recordId)
        external
        onlyRegisteredPatient
        recordExists(recordId)
    {
        require(records[recordId].patient == msg.sender, "MediChain: not your record");
        require(doctors[doctor].registered, "MediChain: target is not a registered doctor");

        bytes32 key = _permissionKey(msg.sender, doctor, recordId);
        require(!permissions[key], "MediChain: access already granted");

        permissions[key] = true;

        _logAudit(msg.sender, doctor, "access_granted", recordId);
        emit AccessGranted(msg.sender, doctor, recordId, block.timestamp);
    }

    /**
     * @notice Revoke a doctor's access to a specific record
     * @param doctor Doctor's wallet address
     * @param recordId ID of the record
     */
    function revokeAccess(address doctor, uint256 recordId)
        external
        onlyRegisteredPatient
        recordExists(recordId)
    {
        require(records[recordId].patient == msg.sender, "MediChain: not your record");

        bytes32 key = _permissionKey(msg.sender, doctor, recordId);
        require(permissions[key], "MediChain: access not granted");

        permissions[key] = false;

        _logAudit(msg.sender, doctor, "access_revoked", recordId);
        emit AccessRevoked(msg.sender, doctor, recordId, block.timestamp);
    }

    // ─── Doctor functions ─────────────────────────────────────────────────────

    /**
     * @notice Register as a doctor
     * @param name Doctor's full name
     * @param specialization Medical specialization
     * @param licenseNumber Medical license number
     */
    function registerDoctor(
        string calldata name,
        string calldata specialization,
        string calldata licenseNumber
    ) external {
        require(!doctors[msg.sender].registered, "MediChain: already registered as doctor");
        require(bytes(name).length > 0, "MediChain: name cannot be empty");

        doctors[msg.sender] = Doctor({
            wallet: msg.sender,
            name: name,
            specialization: specialization,
            licenseNumber: licenseNumber,
            registered: true,
            verified: false,
            registeredAt: block.timestamp
        });

        _logAudit(msg.sender, address(0), "doctor_registered", 0);
        emit DoctorRegistered(msg.sender, name, specialization, block.timestamp);
    }

    /**
     * @notice Check if a doctor has access to a record and emit an access event
     * @param patient Patient's wallet address
     * @param recordId ID of the record
     */
    function accessRecord(address patient, uint256 recordId)
        external
        onlyRegisteredDoctor
        recordExists(recordId)
    {
        bytes32 key = _permissionKey(patient, msg.sender, recordId);
        require(permissions[key], "MediChain: no access permission");

        _logAudit(msg.sender, patient, "record_accessed", recordId);
        emit RecordAccessed(msg.sender, patient, recordId, block.timestamp);
    }

    // ─── Admin functions ──────────────────────────────────────────────────────

    /**
     * @notice Verify a doctor's credentials (admin only)
     * @param doctor Doctor's wallet address
     */
    function verifyDoctor(address doctor) external onlyOwner {
        require(doctors[doctor].registered, "MediChain: not a registered doctor");
        doctors[doctor].verified = true;
        emit DoctorVerified(doctor, block.timestamp);
    }

    // ─── View functions ───────────────────────────────────────────────────────

    /**
     * @notice Check if a doctor has access to a record
     */
    function hasAccess(address patient, address doctor, uint256 recordId)
        external
        view
        returns (bool)
    {
        return permissions[_permissionKey(patient, doctor, recordId)];
    }

    /**
     * @notice Get all record IDs for a patient
     */
    function getPatientRecords(address patient)
        external
        view
        returns (uint256[] memory)
    {
        return patientRecords[patient];
    }

    /**
     * @notice Get a specific record (returns only basic fields for privacy)
     */
    function getRecord(uint256 recordId)
        external
        view
        recordExists(recordId)
        returns (
            uint256 id,
            address patient,
            string memory ipfsCid,
            string memory fileHash,
            string memory recordType,
            string memory title,
            uint256 timestamp
        )
    {
        MedicalRecord storage r = records[recordId];
        return (r.id, r.patient, r.ipfsCid, r.fileHash, r.recordType, r.title, r.timestamp);
    }

    /**
     * @notice Get total number of audit entries
     */
    function getAuditLogLength() external view returns (uint256) {
        return auditLog.length;
    }

    // ─── Internal ─────────────────────────────────────────────────────────────

    function _permissionKey(address patient, address doctor, uint256 recordId)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encodePacked(patient, doctor, recordId));
    }

    function _logAudit(
        address actor,
        address target,
        string memory action,
        uint256 entityId
    ) internal {
        auditLog.push(AuditEntry({
            actor: actor,
            target: target,
            action: action,
            entityId: entityId,
            timestamp: block.timestamp
        }));

        emit AuditLogged(actor, action, entityId, block.timestamp);
    }
}
