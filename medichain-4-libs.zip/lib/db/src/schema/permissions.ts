import { pgTable, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { medicalRecordsTable } from "./medical_records";

export const permissionsTable = pgTable("permissions", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  doctorId: integer("doctor_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  recordId: integer("record_id")
    .notNull()
    .references(() => medicalRecordsTable.id, { onDelete: "cascade" }),
  isActive: boolean("is_active").notNull().default(true),
  grantedAt: timestamp("granted_at").notNull().defaultNow(),
  revokedAt: timestamp("revoked_at"),
});

export const insertPermissionSchema = createInsertSchema(permissionsTable).omit({
  id: true,
  grantedAt: true,
  revokedAt: true,
});
export type InsertPermission = z.infer<typeof insertPermissionSchema>;
export type Permission = typeof permissionsTable.$inferSelect;
