import { pgTable, serial, integer, text, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const recordTypeEnum = pgEnum("record_type", [
  "lab_report",
  "prescription",
  "diagnosis",
  "xray",
  "mri_ct",
  "vaccination",
  "other",
]);

export const medicalRecordsTable = pgTable("medical_records", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  recordType: recordTypeEnum("record_type").notNull().default("other"),
  description: text("description"),
  ipfsCid: text("ipfs_cid").notNull(),
  fileHash: text("file_hash").notNull(),
  encryptedKey: text("encrypted_key"),
  diagnosis: text("diagnosis"),
  medications: text("medications"),
  allergies: text("allergies"),
  doctorNotes: text("doctor_notes"),
  blockchainTxHash: text("blockchain_tx_hash"),
  isOnChain: boolean("is_on_chain").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertMedicalRecordSchema = createInsertSchema(medicalRecordsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertMedicalRecord = z.infer<typeof insertMedicalRecordSchema>;
export type MedicalRecord = typeof medicalRecordsTable.$inferSelect;
