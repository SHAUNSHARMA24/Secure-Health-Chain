import { pgTable, serial, integer, text, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const auditActionEnum = pgEnum("audit_action", [
  "record_uploaded",
  "record_viewed",
  "record_downloaded",
  "record_deleted",
  "permission_granted",
  "permission_revoked",
  "access_requested",
  "user_registered",
  "user_logged_in",
  "wallet_connected",
  "blockchain_verified",
]);

export const auditEntityTypeEnum = pgEnum("audit_entity_type", [
  "record",
  "permission",
  "user",
  "blockchain",
]);

export const auditLogsTable = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  targetUserId: integer("target_user_id").references(() => usersTable.id),
  action: auditActionEnum("action").notNull(),
  entityType: auditEntityTypeEnum("entity_type").notNull(),
  entityId: integer("entity_id"),
  metadata: text("metadata"),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAuditLogSchema = createInsertSchema(auditLogsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogsTable.$inferSelect;
