import { Link } from 'wouter';
import { Activity } from 'lucide-react';

export function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md space-y-8">
          <div className="flex justify-center md:justify-start">
            <Link href="/" className="flex items-center gap-2 text-primary font-bold text-2xl">
              <Activity className="h-8 w-8 text-accent" />
              MediChain
            </Link>
          </div>
          {children}
        </div>
      </div>
      <div className="hidden md:flex flex-1 bg-primary text-primary-foreground items-center justify-center p-12 relative overflow-hidden">
        {/* Abstract background elements */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-[-10%] right-[-5%] w-96 h-96 bg-accent rounded-full blur-[100px]" />
          <div className="absolute bottom-[-10%] left-[-10%] w-[30rem] h-[30rem] bg-blue-500 rounded-full blur-[120px]" />
        </div>
        
        <div className="max-w-lg relative z-10">
          <h2 className="text-4xl font-bold mb-6">Cryptographic Trust for Healthcare.</h2>
          <p className="text-lg text-primary-foreground/80 mb-8 leading-relaxed">
            Take absolute control of your medical history. Share records with providers instantly, trace every access via immutable audit logs, and revoke permissions at any time.
          </p>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <div className="text-2xl font-bold text-accent">100%</div>
              <div className="text-sm text-primary-foreground/70">Patient Owned</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-accent">AES-256</div>
              <div className="text-sm text-primary-foreground/70">End-to-End Encryption</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}