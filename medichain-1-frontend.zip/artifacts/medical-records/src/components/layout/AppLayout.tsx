import { useLocation } from 'wouter';
import { useGetMe, getGetMeQueryKey } from '@workspace/api-client-react';
import { getToken, clearToken } from '@/lib/auth';
import { useEffect } from 'react';
import { Link } from 'wouter';
import {
  Activity,
  FileText,
  ShieldAlert,
  Users,
  UserCircle,
  LogOut,
  LayoutDashboard,
  Menu,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const token = getToken();

  const { data: user, isLoading, isError } = useGetMe({
    query: { retry: false, enabled: !!token, queryKey: getGetMeQueryKey() },
  });

  useEffect(() => {
    if (!token || isError) {
      clearToken();
      setLocation('/login');
    }
  }, [token, isError, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <header className="h-16 border-b flex items-center px-6">
          <Skeleton className="h-6 w-32" />
        </header>
        <div className="flex-1 flex p-6 gap-6">
          <Skeleton className="w-64 h-[calc(100vh-8rem)] rounded-xl" />
          <Skeleton className="flex-1 h-[calc(100vh-8rem)] rounded-xl" />
        </div>
      </div>
    );
  }

  if (!user) return null;

  const isPatient = user.role === 'patient';

  const patientLinks = [
    { href: '/patient/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/patient/records', label: 'Medical Records', icon: FileText },
    { href: '/patient/permissions', label: 'Access Control', icon: ShieldAlert },
    { href: '/patient/audit', label: 'Audit Log', icon: Activity },
  ];

  const doctorLinks = [
    { href: '/doctor/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/doctor/patients', label: 'My Patients', icon: Users },
  ];

  const links = isPatient ? patientLinks : doctorLinks;

  const handleLogout = () => {
    clearToken();
    setLocation('/login');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 border-r bg-card flex flex-col">
        <div className="h-16 flex items-center px-6 border-b">
          <div className="flex items-center gap-2 text-primary font-bold text-lg">
            <Activity className="h-6 w-6 text-accent" />
            MediChain
          </div>
        </div>
        <div className="p-4 flex-1 flex flex-col gap-1">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-2">
            {isPatient ? 'Patient Portal' : 'Provider Portal'}
          </div>
          {links.map((link) => (
            <Link key={link.href} href={link.href} className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium transition-colors text-foreground">
              <link.icon className="h-4 w-4 text-muted-foreground" />
              {link.label}
            </Link>
          ))}
          <div className="mt-8 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-2">
            Settings
          </div>
          <Link href="/profile" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium transition-colors text-foreground">
            <UserCircle className="h-4 w-4 text-muted-foreground" />
            Profile
          </Link>
        </div>
        <div className="p-4 border-t">
          <div className="flex items-center gap-3 mb-4 px-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 overflow-hidden">
              <div className="text-sm font-medium truncate">{user.name}</div>
              <div className="text-xs text-muted-foreground truncate">{user.email}</div>
            </div>
          </div>
          <Button variant="outline" className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-6xl mx-auto space-y-6">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}