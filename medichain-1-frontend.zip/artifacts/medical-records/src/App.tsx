import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Router as WouterRouter } from 'wouter';

// Pages
import LandingPage from '@/pages/index';
import LoginPage from '@/pages/login';
import RegisterPage from '@/pages/register';
import PatientDashboard from '@/pages/patient/dashboard';
import PatientRecords from '@/pages/patient/records';
import PatientUploadRecord from '@/pages/patient/upload';
import PatientPermissions from '@/pages/patient/permissions';
import PatientAudit from '@/pages/patient/audit';
import DoctorDashboard from '@/pages/doctor/dashboard';
import DoctorPatients from '@/pages/doctor/patients';
import DoctorRecords from '@/pages/doctor/records';
import ProfilePage from '@/pages/profile';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      
      <Route path="/patient/dashboard" component={PatientDashboard} />
      <Route path="/patient/records" component={PatientRecords} />
      <Route path="/patient/records/upload" component={PatientUploadRecord} />
      <Route path="/patient/permissions" component={PatientPermissions} />
      <Route path="/patient/audit" component={PatientAudit} />
      
      <Route path="/doctor/dashboard" component={DoctorDashboard} />
      <Route path="/doctor/patients" component={DoctorPatients} />
      <Route path="/doctor/records" component={DoctorRecords} />
      
      <Route path="/profile" component={ProfilePage} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL?.replace(/\/$/, '') || ''}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;