import { AppLayout } from '@/components/layout/AppLayout';
import { useGetMe, useUpdateProfile } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Fingerprint, Wallet } from 'lucide-react';
import { useEffect, useRef } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { getGetMeQueryKey } from '@workspace/api-client-react';

const profileSchema = z.object({
  name: z.string().min(2, 'Name is required'),
  phone: z.string().optional().nullable(),
  dateOfBirth: z.string().optional().nullable(),
  bloodGroup: z.string().optional().nullable(),
  gender: z.string().optional().nullable(),
  walletAddress: z.string().optional().nullable(),
  specialization: z.string().optional().nullable(), // For doctors
});

export default function Profile() {
  const { data: user, isLoading } = useGetMe();
  const updateProfile = useUpdateProfile();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: '', phone: '', dateOfBirth: '', bloodGroup: '', gender: '', walletAddress: '', specialization: ''
    },
  });

  const initializedRef = useRef(false);

  useEffect(() => {
    if (user && !initializedRef.current) {
      form.reset({
        name: user.name,
        phone: user.phone || '',
        dateOfBirth: user.dateOfBirth ? user.dateOfBirth.split('T')[0] : '',
        bloodGroup: user.bloodGroup || '',
        gender: user.gender || '',
        walletAddress: user.walletAddress || '',
        specialization: user.specialization || '',
      });
      initializedRef.current = true;
    }
  }, [user, form]);

  const onSubmit = (values: z.infer<typeof profileSchema>) => {
    updateProfile.mutate({ data: values }, {
      onSuccess: (updatedUser) => {
        toast({ title: 'Identity Updated', description: 'Your profile has been saved.' });
        queryClient.setQueryData(getGetMeQueryKey(), updatedUser);
      },
      onError: (err) => {
        toast({ variant: 'destructive', title: 'Update Failed', description: err.message });
      }
    });
  };

  const handleConnectWallet = () => {
    // Simulate MetaMask connection
    const fakeWallet = '0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('');
    form.setValue('walletAddress', fakeWallet);
    toast({ title: 'Wallet Connected', description: 'Hardware wallet linked successfully.' });
  };

  if (isLoading || !user) {
    return <AppLayout><div className="animate-pulse h-96 bg-muted rounded-xl"></div></AppLayout>;
  }

  const isDoctor = user.role === 'doctor';

  return (
    <AppLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-primary">Identity Settings</h1>
        <p className="text-muted-foreground mt-2">Manage your cryptographic profile and personal details.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem className="col-span-2 sm:col-span-1">
                          <FormLabel>Full Legal Name</FormLabel>
                          <FormControl><Input {...field} value={field.value || ''} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem className="col-span-2 sm:col-span-1">
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl><Input placeholder="+1..." {...field} value={field.value || ''} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {!isDoctor && (
                    <div className="grid grid-cols-3 gap-6">
                      <FormField
                        control={form.control}
                        name="dateOfBirth"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date of Birth</FormLabel>
                            <FormControl><Input type="date" {...field} value={field.value || ''} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="bloodGroup"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Blood Group</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ''}>
                              <FormControl><SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger></FormControl>
                              <SelectContent>
                                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => (
                                  <SelectItem key={bg} value={bg}>{bg}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="gender"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gender</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ''}>
                              <FormControl><SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="Male">Male</SelectItem>
                                <SelectItem value="Female">Female</SelectItem>
                                <SelectItem value="Other">Other</SelectItem>
                                <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}

                  {isDoctor && (
                    <FormField
                      control={form.control}
                      name="specialization"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Specialization</FormLabel>
                          <FormControl><Input {...field} value={field.value || ''} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <div className="pt-4 border-t flex justify-end">
                    <Button type="submit" disabled={updateProfile.isPending}>
                      {updateProfile.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                      Save Changes
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="bg-primary text-primary-foreground border-primary">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Fingerprint className="w-5 h-5 text-accent" /> Digital Identity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-xs text-primary-foreground/70 uppercase tracking-wider mb-1">Account ID</div>
                <div className="font-mono text-sm bg-black/20 p-2 rounded break-all">USR-{user.id.toString().padStart(6, '0')}</div>
              </div>
              <div>
                <div className="text-xs text-primary-foreground/70 uppercase tracking-wider mb-1">Status</div>
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-accent/20 text-accent font-semibold text-xs uppercase tracking-wider">
                  <div className="w-2 h-2 rounded-full bg-accent animate-pulse" /> Verified
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Wallet className="w-5 h-5" /> Web3 Wallet
              </CardTitle>
              <CardDescription>Link hardware wallet for blockchain signatures.</CardDescription>
            </CardHeader>
            <CardContent>
              {form.watch('walletAddress') ? (
                <div className="space-y-4">
                  <div className="font-mono text-xs bg-muted p-3 rounded break-all border border-accent">
                    {form.watch('walletAddress')}
                  </div>
                  <Button variant="outline" className="w-full text-xs" onClick={() => form.setValue('walletAddress', '')}>Disconnect Wallet</Button>
                </div>
              ) : (
                <Button className="w-full gap-2 bg-blue-600 hover:bg-blue-700 text-white" onClick={handleConnectWallet}>
                  Connect MetaMask
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}