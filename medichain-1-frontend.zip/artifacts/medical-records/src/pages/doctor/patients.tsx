import { AppLayout } from '@/components/layout/AppLayout';
import { useGetMyPatients } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { Users, FileText, ChevronRight, Droplet } from 'lucide-react';
import { format } from 'date-fns';

export default function DoctorPatients() {
  const { data: patients, isLoading } = useGetMyPatients();

  return (
    <AppLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-primary">Patient Panel</h1>
        <p className="text-muted-foreground mt-2">
          Patients who have cryptographically authorized you to view their records.
        </p>
      </div>

      {isLoading ? (
        <div className="grid gap-4">
          {[1,2,3].map(i => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}
        </div>
      ) : !patients || patients.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/5 flex items-center justify-center mb-4">
              <Users className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">No active authorizations</h3>
            <p className="text-muted-foreground max-w-sm">
              Patients must explicitly grant you access via their dashboard before they appear here.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {patients.map(patient => (
            <Card key={patient.id} className="hover:shadow-md transition-shadow group border-l-4 border-l-accent">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="font-bold text-xl text-primary">{patient.name}</h3>
                    <div className="text-sm text-muted-foreground">{patient.email}</div>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center text-accent font-bold text-lg">
                    {patient.name.charAt(0)}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                  <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1 flex items-center gap-1"><FileText className="w-3 h-3"/> Records</div>
                    <div className="font-semibold">{patient.recordCount} authorized</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1 flex items-center gap-1"><Droplet className="w-3 h-3"/> Blood</div>
                    <div className="font-semibold">{patient.bloodGroup || 'Unknown'}</div>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground font-mono mb-4 pt-4 border-t">
                  Access Granted: {format(new Date(patient.permissionGrantedAt), 'MMM d, yyyy')}
                </div>

                <Link href={`/doctor/records?patientId=${patient.id}`}>
                  <Button className="w-full justify-between bg-primary/5 text-primary hover:bg-primary/10 hover:text-primary">
                    View Decrypted Vault <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </AppLayout>
  );
}