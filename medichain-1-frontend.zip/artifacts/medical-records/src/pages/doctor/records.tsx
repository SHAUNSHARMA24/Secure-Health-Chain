import { AppLayout } from '@/components/layout/AppLayout';
import { useListRecords, useGetRecord, useVerifyRecord, getListRecordsQueryKey, getGetRecordQueryKey, getVerifyRecordQueryKey } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, ShieldCheck, ArrowLeft, Download, ShieldAlert } from 'lucide-react';
import { format } from 'date-fns';
import { Link, useSearch } from 'wouter';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export default function DoctorRecords() {
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const patientId = params.get('patientId');
  const { toast } = useToast();

  const { data: records, isLoading } = useListRecords(
    patientId ? { patientId } : undefined,
    { query: { enabled: !!patientId, queryKey: getListRecordsQueryKey(patientId ? { patientId } : undefined) } }
  );

  const [selectedRecordId, setSelectedRecordId] = useState<number | null>(null);
  const { data: selectedRecord, isLoading: loadingRecord } = useGetRecord(
    selectedRecordId as number,
    { query: { enabled: !!selectedRecordId, queryKey: getGetRecordQueryKey(selectedRecordId as number) } }
  );

  const [verifyingId, setVerifyingId] = useState<number | null>(null);
  const verifyMutation = useVerifyRecord(verifyingId as number, { query: { enabled: false, queryKey: getVerifyRecordQueryKey(verifyingId as number) }});

  if (!patientId) {
    return (
      <AppLayout>
        <div className="p-8 text-center">Invalid Request. No Patient ID provided.</div>
      </AppLayout>
    );
  }

  const handleVerify = async (id: number) => {
    setVerifyingId(id);
    try {
      const res = await verifyMutation.refetch();
      if (res.data?.isValid) {
        toast({ title: 'Integrity Verified', description: 'Cryptographic hash matches stored blockchain signature.' });
      } else {
        toast({ variant: 'destructive', title: 'Verification Failed', description: 'Record hash mismatch.' });
      }
    } catch (e) {
      toast({ variant: 'destructive', title: 'Error', description: 'Could not verify record.' });
    } finally {
      setVerifyingId(null);
    }
  };

  return (
    <AppLayout>
      <div className="mb-8">
        <Link href="/doctor/patients">
          <Button variant="ghost" className="mb-4 gap-2 -ml-4 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Back to Panel
          </Button>
        </Link>
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold tracking-tight text-primary">Patient Vault</h1>
          <div className="px-3 py-1 rounded-full bg-accent/10 text-accent text-sm font-semibold flex items-center gap-1">
            <ShieldCheck className="w-4 h-4" /> Decryption Active
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-4">
          {[1,2,3].map(i => <div key={i} className="h-32 bg-muted rounded-xl animate-pulse" />)}
        </div>
      ) : !records || records.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-16 text-center text-muted-foreground">
            Patient has not authorized any records for your view.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {records.map(record => (
            <Card key={record.id} className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-transparent hover:border-l-primary" onClick={() => setSelectedRecordId(record.id)}>
              <div className="p-5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/5 flex items-center justify-center shrink-0">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{record.title}</h3>
                    <div className="text-sm text-muted-foreground flex gap-3 items-center">
                      <span className="uppercase tracking-wider text-xs font-semibold text-accent">{record.recordType.replace('_', ' ')}</span>
                      <span>&bull;</span>
                      <span>{format(new Date(record.createdAt), 'MMM d, yyyy')}</span>
                    </div>
                  </div>
                </div>
                <Button variant="ghost" className="rounded-full w-10 h-10 p-0 shrink-0">
                  <ChevronRightIcon className="w-5 h-5 text-muted-foreground" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Record Viewer Dialog */}
      <Dialog open={!!selectedRecordId} onOpenChange={(open) => !open && setSelectedRecordId(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl">
              <ShieldCheck className="w-6 h-6 text-accent" /> Decrypted Record
            </DialogTitle>
          </DialogHeader>
          
          {loadingRecord || !selectedRecord ? (
            <div className="h-64 flex items-center justify-center">Decrypting payload...</div>
          ) : (
            <div className="space-y-6 mt-4">
              <div className="flex items-center justify-between border-b pb-4">
                <div>
                  <h2 className="text-2xl font-bold text-primary">{selectedRecord.title}</h2>
                  <div className="text-sm text-muted-foreground uppercase tracking-wider font-semibold mt-1">
                    {selectedRecord.recordType.replace('_', ' ')}
                  </div>
                </div>
                <Button variant="outline" className="gap-2" onClick={(e) => { e.stopPropagation(); handleVerify(selectedRecord.id); }} disabled={verifyingId === selectedRecord.id}>
                  {verifyingId === selectedRecord.id ? '...' : <><ShieldAlert className="w-4 h-4"/> Verify Hash</>}
                </Button>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  {selectedRecord.description && (
                    <div>
                      <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Description</h4>
                      <p className="text-sm leading-relaxed">{selectedRecord.description}</p>
                    </div>
                  )}
                  {selectedRecord.diagnosis && (
                    <div>
                      <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Diagnosis</h4>
                      <p className="text-sm leading-relaxed font-medium">{selectedRecord.diagnosis}</p>
                    </div>
                  )}
                  {selectedRecord.medications && (
                    <div>
                      <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Medications</h4>
                      <p className="text-sm leading-relaxed">{selectedRecord.medications}</p>
                    </div>
                  )}
                  {selectedRecord.allergies && (
                    <div>
                      <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Allergies</h4>
                      <p className="text-sm leading-relaxed text-destructive font-medium">{selectedRecord.allergies}</p>
                    </div>
                  )}
                </div>
                
                <div className="space-y-6 bg-muted/50 p-6 rounded-xl border">
                  <h4 className="text-sm font-bold text-foreground mb-4">Cryptographic Metadata</h4>
                  <div>
                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">IPFS CID</div>
                    <div className="font-mono text-xs bg-card border p-2 rounded break-all">{selectedRecord.ipfsCid}</div>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">SHA-256 Hash</div>
                    <div className="font-mono text-xs bg-card border p-2 rounded break-all">{selectedRecord.fileHash}</div>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Transaction</div>
                    <div className="font-mono text-xs bg-card border p-2 rounded break-all text-accent">{selectedRecord.blockchainTxHash || 'Pending'}</div>
                  </div>
                </div>
              </div>

              <div className="pt-6 flex justify-end gap-4 border-t">
                <Button variant="outline" onClick={() => setSelectedRecordId(null)}>Close Viewer</Button>
                <Button className="gap-2 bg-primary text-primary-foreground"><Download className="w-4 h-4" /> Export PDF</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

function ChevronRightIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="9 18 15 12 9 6"/>
    </svg>
  );
}