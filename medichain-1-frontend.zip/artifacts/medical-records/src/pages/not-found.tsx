import { Link } from 'wouter';
import { Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center text-center p-4">
      <Activity className="w-16 h-16 text-muted-foreground mb-6" />
      <h1 className="text-4xl font-bold text-primary mb-2">404</h1>
      <p className="text-xl text-muted-foreground mb-8">Resource not found or access denied.</p>
      <Link href="/">
        <Button size="lg">Return to Gateway</Button>
      </Link>
    </div>
  );
}