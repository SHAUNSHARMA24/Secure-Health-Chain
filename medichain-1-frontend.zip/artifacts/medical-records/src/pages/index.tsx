import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Activity, ShieldCheck, Database, LockKeyhole, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b bg-background/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-primary font-bold text-xl">
            <Activity className="h-6 w-6 text-accent" />
            MediChain
          </div>
          <nav className="hidden md:flex gap-6 text-sm font-medium">
            <a href="#features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
            <a href="#security" className="text-muted-foreground hover:text-primary transition-colors">Security</a>
            <a href="#providers" className="text-muted-foreground hover:text-primary transition-colors">For Providers</a>
          </nav>
          <div className="flex gap-4">
            <Link href="/login">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link href="/register">
              <Button className="bg-primary text-primary-foreground">Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-24 md:py-32 overflow-hidden relative">
          <div className="absolute top-0 right-0 -translate-y-12 translate-x-1/3 w-[800px] h-[800px] bg-accent/5 rounded-full blur-[120px] pointer-events-none" />
          <div className="absolute bottom-0 left-0 translate-y-1/3 -translate-x-1/3 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
          
          <div className="container mx-auto px-6 relative z-10 text-center max-w-4xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 text-accent font-semibold text-xs uppercase tracking-wide mb-8">
              <ShieldCheck className="w-4 h-4" /> The future of medical records
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-primary mb-8 leading-[1.1]">
              Clinical precision meets <br/><span className="text-accent">cryptographic trust.</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
              MediChain is a decentralized healthcare platform where patients own their encrypted medical records, grant selective doctor access, and every action is audited immutably.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/register">
                <Button size="lg" className="w-full sm:w-auto text-lg h-14 px-8 gap-2">
                  Create Patient Wallet <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Link href="/register?role=doctor">
                <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg h-14 px-8">
                  Provider Registration
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-24 bg-muted/50 border-y">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Zero-Trust Healthcare Infrastructure</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto text-lg">We redesigned the medical record system from the ground up to eliminate central points of failure and put the patient in total control.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {[
                {
                  icon: Database,
                  title: 'IPFS Storage',
                  desc: 'Records are encrypted and stored across the InterPlanetary File System, ensuring they cannot be tampered with or lost.'
                },
                {
                  icon: LockKeyhole,
                  title: 'Granular Access',
                  desc: 'Grant providers access to specific records for defined timeframes. Revoke access instantly with a single click.'
                },
                {
                  icon: ShieldCheck,
                  title: 'Immutable Audit Trail',
                  desc: 'Every view, upload, and permission change is logged on-chain. You always know exactly who looked at your data and when.'
                }
              ].map((f, i) => (
                <div key={i} className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-primary/5 flex items-center justify-center mb-6">
                    <f.icon className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">{f.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Security Metrics */}
        <section id="security" className="py-24">
          <div className="container mx-auto px-6 max-w-5xl">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">Military-grade encryption for your most sensitive data.</h2>
                <div className="space-y-4">
                  {[
                    'AES-256 Client-side Encryption',
                    'SHA-256 File Hashing',
                    'Smart Contract Access Control',
                    'HIPAA Compliant Architecture'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-accent" />
                      <span className="font-medium text-foreground">{item}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-8">
                  <Link href="/register">
                    <Button variant="link" className="text-accent px-0 hover:text-primary">
                      Read our security whitepaper <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="bg-card border rounded-2xl p-8 shadow-xl">
                <div className="space-y-6 font-mono text-sm">
                  <div className="space-y-2">
                    <div className="text-muted-foreground">Transaction Hash</div>
                    <div className="bg-muted p-3 rounded-lg break-all text-primary">0x8f3c...7a9b21f3c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-muted-foreground">IPFS CID</div>
                    <div className="bg-muted p-3 rounded-lg break-all text-primary">QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG</div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-accent" />
                      <span className="text-accent font-semibold">Integrity Verified</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-12 bg-muted/30">
        <div className="container mx-auto px-6 text-center text-muted-foreground">
          <p className="flex items-center justify-center gap-2 mb-4">
            <Activity className="h-5 w-5 text-accent" />
            <span className="font-bold text-primary">MediChain</span>
          </p>
          <p>© {new Date().getFullYear()} MediChain Protocol. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}