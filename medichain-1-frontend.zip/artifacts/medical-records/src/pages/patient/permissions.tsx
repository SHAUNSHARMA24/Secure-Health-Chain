import { AppLayout } from '@/components/layout/AppLayout';
import { useListPermissions, useRevokePermission, getListPermissionsQueryKey, useListDoctors, useListRecords, useGrantPermission } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShieldAlert, ShieldX, KeyRound, Plus, Lock } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useState } from 'react';

const grantSchema = z.object({
  doctorId: z.string().min(1, 'Please select a provider'),
  recordId: z.string().min(1, 'Please select a record to share'),
});

export default function PatientPermissions() {
  const { data: permissions, isLoading } = useListPermissions();
  const revokeMutation = useRevokePermission();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: doctors } = useListDoctors();
  const { data: records } = useListRecords();
  const grantMutation = useGrantPermission();

  const form = useForm<z.infer<typeof grantSchema>>({
    resolver: zodResolver(grantSchema),
    defaultValues: { doctorId: '', recordId: '' },
  });

  const handleRevoke = (id: number) => {
    revokeMutation.mutate({ id }, {
      onSuccess: () => {
        toast({ title: 'Access Revoked', description: 'Cryptographic access key destroyed.' });
        queryClient.invalidateQueries({ queryKey: getListPermissionsQueryKey() });
      },
      onError: () => {
        toast({ variant: 'destructive', title: 'Failed to revoke access' });
      }
    });
  };

  const onSubmit = (values: z.infer<typeof grantSchema>) => {
    grantMutation.mutate({
      data: {
        doctorId: parseInt(values.doctorId, 10),
        recordId: parseInt(values.recordId, 10),
      }
    }, {
      onSuccess: () => {
        toast({ title: 'Access Granted', description: 'Provider can now decrypt this record.' });
        queryClient.invalidateQueries({ queryKey: getListPermissionsQueryKey() });
        setIsDialogOpen(false);
        form.reset();
      },
      onError: (err) => {
        toast({ variant: 'destructive', title: 'Failed to grant access', description: err.message });
      }
    });
  };

  const activePermissions = permissions?.filter(p => p.isActive) || [];
  const historicalPermissions = permissions?.filter(p => !p.isActive) || [];

  return (
    <AppLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Access Control</h1>
          <p className="text-muted-foreground mt-2">Manage who holds decryption keys to your records.</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <KeyRound className="w-4 h-4" /> Grant Access
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Grant Provider Access</DialogTitle>
              <DialogDescription>
                Securely share a record's decryption key with a verified healthcare provider.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="doctorId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Provider</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select provider..." /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {doctors?.map(d => (
                            <SelectItem key={d.id} value={d.id.toString()}>Dr. {d.name} ({d.specialization})</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="recordId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Medical Record</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select record..." /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {records?.map(r => (
                            <SelectItem key={r.id} value={r.id.toString()}>{r.title} ({format(new Date(r.createdAt), 'MMM d, yyyy')})</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={grantMutation.isPending}>
                  {grantMutation.isPending ? 'Processing...' : 'Authorize Request'}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-8">
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Lock className="w-5 h-5 text-accent" /> Active Grants
          </h2>
          {isLoading ? (
            <div className="h-32 bg-muted rounded-xl animate-pulse" />
          ) : activePermissions.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-8 text-center text-muted-foreground">
                No active provider access. Your vault is completely locked.
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {activePermissions.map(p => (
                <Card key={p.id} className="border-l-4 border-l-accent overflow-hidden">
                  <div className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="font-bold text-lg">Dr. {p.doctorName}</div>
                      <div className="text-sm text-muted-foreground mb-2">Granted access to: <span className="font-semibold text-foreground">{p.recordTitle}</span></div>
                      <div className="text-xs text-muted-foreground font-mono">
                        Authorized: {format(new Date(p.grantedAt), 'MMM d, yyyy HH:mm:ss')}
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      className="text-destructive hover:bg-destructive/10 hover:text-destructive gap-2 w-full md:w-auto"
                      onClick={() => handleRevoke(p.id)}
                      disabled={revokeMutation.isPending}
                    >
                      <ShieldX className="w-4 h-4" /> Revoke Key
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>

        {historicalPermissions.length > 0 && (
          <section>
            <h2 className="text-xl font-bold mb-4 text-muted-foreground">Revoked Access History</h2>
            <div className="grid gap-3 opacity-60 hover:opacity-100 transition-opacity">
              {historicalPermissions.map(p => (
                <Card key={p.id} className="bg-muted/50">
                  <div className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="font-semibold">Dr. {p.doctorName} <span className="text-xs font-normal ml-2">({p.recordTitle})</span></div>
                      <div className="text-xs font-mono mt-1 text-destructive">
                        Revoked: {p.revokedAt ? format(new Date(p.revokedAt), 'MMM d, yyyy HH:mm:ss') : 'Unknown'}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>
        )}
      </div>
    </AppLayout>
  );
}