import { AppLayout } from '@/components/layout/AppLayout';
import { useCreateRecord, MedicalRecordInputRecordType } from '@workspace/api-client-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2, ShieldCheck, FileKey2 } from 'lucide-react';
import { useState } from 'react';

// Fake cryptographic generator for UI feel
const generateFakeHash = () => '0x' + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('');
const generateFakeCid = () => 'Qm' + Array.from({length: 44}, () => Math.floor(Math.random()*36).toString(36)).join('');

const formSchema = z.object({
  title: z.string().min(2, 'Title is required'),
  recordType: z.enum([
    'lab_report', 'prescription', 'diagnosis', 'xray', 'mri_ct', 'vaccination', 'other'
  ]),
  description: z.string().optional(),
  diagnosis: z.string().optional(),
  medications: z.string().optional(),
  allergies: z.string().optional(),
  doctorNotes: z.string().optional(),
});

export default function PatientUploadRecord() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createRecord = useCreateRecord();
  
  const [simulatedHash] = useState(generateFakeHash());
  const [simulatedCid] = useState(generateFakeCid());

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      recordType: 'lab_report',
      description: '',
      diagnosis: '',
      medications: '',
      allergies: '',
      doctorNotes: '',
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createRecord.mutate({
      data: {
        ...values,
        recordType: values.recordType as MedicalRecordInputRecordType,
        ipfsCid: simulatedCid,
        fileHash: simulatedHash,
        encryptedKey: 'simulated_encrypted_aes_key',
        blockchainTxHash: generateFakeHash(),
      }
    }, {
      onSuccess: () => {
        toast({
          title: 'Record Secured on Blockchain',
          description: 'Your document was encrypted and uploaded to IPFS.',
        });
        setLocation('/patient/records');
      },
      onError: (err) => {
        toast({ variant: 'destructive', title: 'Upload Failed', description: err.message });
      }
    });
  }

  return (
    <AppLayout>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Encrypt & Upload</h1>
          <p className="text-muted-foreground mt-2">Securely add a document to your IPFS vault.</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card>
            <CardContent className="p-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem className="col-span-2 sm:col-span-1">
                          <FormLabel>Document Title</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Annual Blood Work" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="recordType"
                      render={({ field }) => (
                        <FormItem className="col-span-2 sm:col-span-1">
                          <FormLabel>Record Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="lab_report">Lab Report</SelectItem>
                              <SelectItem value="prescription">Prescription</SelectItem>
                              <SelectItem value="diagnosis">Diagnosis</SelectItem>
                              <SelectItem value="xray">X-Ray</SelectItem>
                              <SelectItem value="mri_ct">MRI / CT Scan</SelectItem>
                              <SelectItem value="vaccination">Vaccination</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Brief description of the record..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="pt-4 border-t">
                    <h3 className="text-lg font-semibold mb-4 text-primary">Clinical Details (Optional)</h3>
                    <div className="grid grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="diagnosis"
                        render={({ field }) => (
                          <FormItem className="col-span-2 sm:col-span-1">
                            <FormLabel>Diagnosis</FormLabel>
                            <FormControl>
                              <Input placeholder="Condition..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="allergies"
                        render={({ field }) => (
                          <FormItem className="col-span-2 sm:col-span-1">
                            <FormLabel>Allergies</FormLabel>
                            <FormControl>
                              <Input placeholder="Penicillin, Peanuts..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="medications"
                        render={({ field }) => (
                          <FormItem className="col-span-2">
                            <FormLabel>Prescribed Medications</FormLabel>
                            <FormControl>
                              <Input placeholder="Lisinopril 10mg..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <Button type="submit" disabled={createRecord.isPending} className="w-full h-12 text-lg gap-2">
                    {createRecord.isPending ? (
                      <><Loader2 className="w-5 h-5 animate-spin" /> Securing on Blockchain...</>
                    ) : (
                      <><FileKey2 className="w-5 h-5" /> Encrypt & Store Record</>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="bg-primary text-primary-foreground border-primary sticky top-24">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-accent" />
                Encryption Routine
              </CardTitle>
              <CardDescription className="text-primary-foreground/70">
                Your data is encrypted locally before touching our servers.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="text-xs uppercase tracking-wider text-accent font-semibold mb-2">Simulated Hash (SHA-256)</div>
                <div className="font-mono text-xs bg-black/30 p-3 rounded-md break-all leading-relaxed">
                  {simulatedHash}
                </div>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wider text-accent font-semibold mb-2">Target IPFS Node</div>
                <div className="font-mono text-xs bg-black/30 p-3 rounded-md break-all leading-relaxed">
                  {simulatedCid}
                </div>
              </div>
              <div className="text-sm text-primary-foreground/80 pt-4 border-t border-primary-foreground/20">
                Upon submission, a Smart Contract event is emitted to immutably timestamp your record.
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}