import { AppLayout } from '@/components/layout/AppLayout';
import { useListRecords, useDeleteRecord, useVerifyRecord, getListRecordsQueryKey, getVerifyRecordQueryKey } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Plus, ShieldCheck, Trash2, ShieldAlert, Link as LinkIcon } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';

export default function PatientRecords() {
  const { data: records, isLoading } = useListRecords();
  const deleteRecord = useDeleteRecord();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [verifyingId, setVerifyingId] = useState<number | null>(null);
  const verifyMutation = useVerifyRecord(verifyingId as number, { query: { enabled: false, queryKey: getVerifyRecordQueryKey(verifyingId as number) }});

  const handleDelete = (id: number) => {
    deleteRecord.mutate({ id }, {
      onSuccess: () => {
        toast({ title: 'Record deleted securely' });
        queryClient.invalidateQueries({ queryKey: getListRecordsQueryKey() });
      },
      onError: () => {
        toast({ variant: 'destructive', title: 'Failed to delete record' });
      }
    });
  };

  const handleVerify = async (id: number) => {
    setVerifyingId(id);
    try {
      const res = await verifyMutation.refetch();
      if (res.data?.isValid) {
        toast({
          title: 'Integrity Verified',
          description: 'Cryptographic hash matches stored blockchain signature.',
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Verification Failed',
          description: 'Record hash mismatch. Data may be compromised.',
        });
      }
    } catch (e) {
      toast({ variant: 'destructive', title: 'Verification Error', description: 'Could not contact blockchain.' });
    } finally {
      setVerifyingId(null);
    }
  };

  return (
    <AppLayout>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Medical Vault</h1>
          <p className="text-muted-foreground mt-2">Manage your encrypted health records.</p>
        </div>
        <Link href="/patient/records/upload">
          <Button className="gap-2">
            <Plus className="w-4 h-4" /> Upload Record
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="grid gap-4">
          {[1,2,3].map(i => <div key={i} className="h-48 bg-muted rounded-xl animate-pulse" />)}
        </div>
      ) : !records || records.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/5 flex items-center justify-center mb-4">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">Vault is empty</h3>
            <p className="text-muted-foreground max-w-sm mb-6">You haven't uploaded any records to the IPFS network yet. Upload your first document to secure it on-chain.</p>
            <Link href="/patient/records/upload">
              <Button>Encrypt & Upload</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {records.map(record => (
            <Card key={record.id} className="overflow-hidden">
              <div className="border-b bg-muted/30 px-6 py-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="font-bold text-lg text-primary">{record.title}</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-semibold uppercase tracking-wider">
                      {record.recordType.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center gap-2">
                    <ClockIcon className="w-3 h-3" />
                    {format(new Date(record.createdAt), 'MMMM d, yyyy')}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="gap-2"
                    onClick={() => handleVerify(record.id)}
                    disabled={verifyingId === record.id}
                  >
                    <ShieldCheck className="w-4 h-4 text-accent" /> 
                    {verifyingId === record.id ? 'Verifying...' : 'Verify Hash'}
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm" className="text-destructive hover:bg-destructive/10">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will delete the record from your vault and revoke all active provider permissions. The blockchain audit log will reflect this deletion.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(record.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                          Confirm Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    {record.description && (
                      <div>
                        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Description</div>
                        <p className="text-sm">{record.description}</p>
                      </div>
                    )}
                    {record.diagnosis && (
                      <div>
                        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Diagnosis</div>
                        <p className="text-sm">{record.diagnosis}</p>
                      </div>
                    )}
                  </div>
                  <div className="space-y-4 font-mono text-xs">
                    <div>
                      <div className="font-sans font-semibold text-muted-foreground uppercase tracking-wider mb-1 text-xs">IPFS CID</div>
                      <div className="bg-muted p-2 rounded break-all border">{record.ipfsCid}</div>
                    </div>
                    <div>
                      <div className="font-sans font-semibold text-muted-foreground uppercase tracking-wider mb-1 text-xs">SHA-256 Hash</div>
                      <div className="bg-muted p-2 rounded break-all border">{record.fileHash}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </AppLayout>
  );
}

function ClockIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
    </svg>
  )
}