import { AppLayout } from '@/components/layout/AppLayout';
import { useListAuditLogs } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Activity, ShieldCheck, Download, Trash2, KeyRound, ShieldX, Eye, UserPlus, LogIn, Link, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';

const getActionIcon = (action: string) => {
  switch(action) {
    case 'record_uploaded': return <ShieldCheck className="w-4 h-4 text-emerald-500" />;
    case 'record_viewed': return <Eye className="w-4 h-4 text-blue-500" />;
    case 'record_downloaded': return <Download className="w-4 h-4 text-purple-500" />;
    case 'record_deleted': return <Trash2 className="w-4 h-4 text-destructive" />;
    case 'permission_granted': return <KeyRound className="w-4 h-4 text-accent" />;
    case 'permission_revoked': return <ShieldX className="w-4 h-4 text-destructive" />;
    case 'user_registered': return <UserPlus className="w-4 h-4 text-emerald-500" />;
    case 'user_logged_in': return <LogIn className="w-4 h-4 text-blue-500" />;
    case 'blockchain_verified': return <Link className="w-4 h-4 text-accent" />;
    default: return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
  }
};

const getActionColor = (action: string) => {
  if (action.includes('revoked') || action.includes('deleted')) return 'border-l-destructive';
  if (action.includes('granted') || action.includes('verified')) return 'border-l-accent';
  return 'border-l-blue-500';
};

export default function PatientAudit() {
  const { data: logs, isLoading } = useListAuditLogs({ limit: 100 });

  return (
    <AppLayout>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Immutable Audit Log</h1>
          <p className="text-muted-foreground mt-2">Every action on your account is cryptographically verified and recorded.</p>
        </div>
      </div>

      <Card className="bg-card">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 space-y-6">
              {[1,2,3,4,5].map(i => <div key={i} className="h-16 bg-muted rounded-lg animate-pulse" />)}
            </div>
          ) : !logs || logs.length === 0 ? (
            <div className="p-16 text-center text-muted-foreground">No audit events recorded yet.</div>
          ) : (
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-[39px] top-8 bottom-8 w-px bg-border hidden md:block" />
              
              <div className="divide-y">
                {logs.map((log) => {
                  const metadata = log.metadata ? JSON.parse(log.metadata) : {};
                  
                  return (
                    <div key={log.id} className="p-4 md:p-6 flex flex-col md:flex-row gap-4 md:gap-6 group hover:bg-muted/30 transition-colors">
                      <div className="flex items-center gap-4 md:w-48 shrink-0">
                        <div className={`w-10 h-10 rounded-full bg-background border shadow-sm flex items-center justify-center relative z-10 shrink-0`}>
                          {getActionIcon(log.action)}
                        </div>
                        <div className="font-mono text-xs text-muted-foreground flex flex-col">
                          <span className="font-bold text-foreground">{format(new Date(log.createdAt), 'MMM d, yyyy')}</span>
                          <span>{format(new Date(log.createdAt), 'HH:mm:ss')}</span>
                        </div>
                      </div>
                      
                      <div className={`flex-1 pl-4 border-l-2 ${getActionColor(log.action)} py-1`}>
                        <div className="font-semibold text-base mb-1 text-foreground">
                          {log.action.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                        </div>
                        <div className="text-sm text-muted-foreground mb-2">
                          <span className="font-medium text-foreground">{log.actorName || 'System'}</span> 
                          {' '}&rarr;{' '}
                          {log.entityType.charAt(0).toUpperCase() + log.entityType.slice(1)}
                          {log.targetName ? ` (${log.targetName})` : ''}
                        </div>
                        
                        {(metadata.title || log.ipAddress) && (
                          <div className="flex gap-4 mt-2">
                            {metadata.title && (
                              <div className="text-xs bg-muted px-2 py-1 rounded font-medium">
                                Target: {metadata.title}
                              </div>
                            )}
                            {log.ipAddress && (
                              <div className="text-xs bg-muted px-2 py-1 rounded font-mono text-muted-foreground">
                                IP: {log.ipAddress}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </AppLayout>
  );
}