# Contributing to MediChain

Thank you for considering contributing to MediChain! This document outlines the process for contributing to this project.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Be respectful, constructive, and welcoming to all contributors.

## How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported in [Issues](../../issues).
2. If not, open a new issue with:
   - A clear title and description
   - Steps to reproduce
   - Expected vs. actual behavior
   - Environment info (OS, Node.js version, etc.)

### Suggesting Features

1. Open an issue with the `enhancement` label.
2. Describe the feature and why it's valuable.
3. If possible, outline a rough implementation approach.

### Submitting Pull Requests

1. Fork the repository.
2. Create a feature branch: `git checkout -b feature/your-feature-name`
3. Follow the code style (ESLint + Prettier are configured).
4. Write or update tests as appropriate.
5. Commit with clear, descriptive messages following [Conventional Commits](https://www.conventionalcommits.org/).
6. Push and open a Pull Request targeting `main`.

## Development Setup

```bash
# Clone the repo
git clone https://github.com/yourname/medichain.git
cd medichain

# Install dependencies
pnpm install

# Set up environment
cp .env.example .env
# Fill in your .env values

# Push database schema
pnpm --filter @workspace/db run push

# Start API server
pnpm --filter @workspace/api-server run dev

# Start frontend
pnpm --filter @workspace/medical-records run dev
```

## Code Style

- TypeScript is required for all backend and frontend code.
- Solidity follows the NatSpec documentation standard.
- Use `pnpm run typecheck` before submitting a PR.
- No `console.log` in server code — use `req.log` or the `logger` singleton.

## Commit Message Format

```
type(scope): short description

body (optional)

footer (optional)
```

Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`

Examples:
- `feat(records): add AES-256 encryption before IPFS upload`
- `fix(auth): handle expired JWT correctly`
- `docs(readme): add MetaMask configuration section`

## Testing

```bash
# Backend typecheck
pnpm --filter @workspace/api-server run typecheck

# Smart contract tests
cd contracts
npx hardhat test

# Frontend typecheck
pnpm --filter @workspace/medical-records run typecheck
```

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
