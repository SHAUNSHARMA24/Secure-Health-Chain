# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 1.x     | ✅ Yes    |

## Reporting a Vulnerability

**Do NOT report security vulnerabilities through public GitHub issues.**

If you discover a security vulnerability, please send an email to:
**security@medichain.io** (replace with your actual contact)

Please include:
- Type of vulnerability (XSS, SQL injection, smart contract exploit, etc.)
- Steps to reproduce
- Potential impact
- Any suggested fixes

You should receive a response within **48 hours**. If you do not, please follow up.

## Security Practices

MediChain takes security seriously. The following measures are implemented:

### Application Layer
- **JWT authentication** with 7-day expiry
- **bcrypt** password hashing (12 rounds)
- **Helmet.js** security headers
- **Rate limiting** on all endpoints (stricter on auth routes)
- **CORS** properly configured
- **Input validation** via Zod schemas on all endpoints
- **SQL injection prevention** via parameterized queries (Drizzle ORM)

### Data Layer
- **AES-256 encryption** for all medical files before IPFS upload
- **SHA-256 hashing** for file integrity verification
- Only IPFS CIDs and hashes are stored on-chain — no raw health data
- Database credentials stored in environment variables only

### Blockchain Layer
- **Immutable audit logs** — every permission change is recorded on-chain
- **Role-based modifiers** in the smart contract enforce access control
- **Permission key hashing** uses `keccak256(patient, doctor, recordId)`
- **Only the contract owner** can verify doctors

### Infrastructure
- All secrets in environment variables (never hardcoded)
- `.env` excluded from version control
- Production environment variables managed separately from development

## Responsible Disclosure

We follow a **90-day disclosure policy**. After 90 days from reporting (or sooner if a fix is released), the vulnerability details may be publicly disclosed.

Thank you for helping keep MediChain and its users safe.
