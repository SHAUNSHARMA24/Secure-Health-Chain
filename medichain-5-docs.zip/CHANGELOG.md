# Changelog

All notable changes to MediChain will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Native IPFS file upload with Pinata SDK
- MetaMask wallet integration for on-chain permission management
- AES-256 client-side encryption before upload
- Mobile app (Expo/React Native)
- Notifications via email when a doctor accesses a record

---

## [1.0.0] - 2026-08-03

### Added
- **Patient registration and login** with JWT authentication
- **Doctor registration and login** with role-based access
- **Medical record upload** — stores IPFS CID, file hash, diagnosis, medications, allergies, doctor notes
- **Record types**: lab_report, prescription, diagnosis, xray, mri_ct, vaccination, other
- **Permission management** — grant and revoke doctor access per record
- **Audit logging** — immutable log of every action (upload, view, permission changes)
- **Dashboard statistics** — totals, breakdown by record type, authorized doctors count
- **Recent activity feed** for both patient and doctor dashboards
- **Record integrity verification** — checks stored hash against IPFS content
- **Doctor directory** — patients can find and select doctors by specialization
- **Doctor patient list** — doctors see all patients who granted access
- **Smart contract** `MediChain.sol` — Solidity 0.8.19
  - Patient and doctor registration
  - On-chain record metadata storage (CID + hash only)
  - Permission grant/revoke with events
  - Immutable on-chain audit log
  - Admin-controlled doctor verification
- **Hardhat** configuration for local, Sepolia, and Polygon Mumbai deployment
- **Comprehensive smart contract tests** (Hardhat + Chai)
- **Security**: Helmet, rate limiting, bcrypt, JWT, CORS, Zod validation
- **PostgreSQL** backend with Drizzle ORM
- **OpenAPI spec** with React Query hook generation via Orval
- Professional README with full deployment guide
- CONTRIBUTING.md, SECURITY.md, CHANGELOG.md, LICENSE

### Architecture
- pnpm monorepo workspace
- Shared OpenAPI spec → generates Zod validators (backend) + React Query hooks (frontend)
- Separate smart contract package with Hardhat toolchain
- Role-based route protection (patient/doctor)

---

## [0.1.0] - Initial scaffold

- Project scaffolded with pnpm monorepo
- Express API server with TypeScript
- React + Vite frontend scaffold
- PostgreSQL + Drizzle ORM setup
