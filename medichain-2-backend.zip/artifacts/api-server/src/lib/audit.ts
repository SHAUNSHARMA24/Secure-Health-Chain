import { db, auditLogsTable } from "@workspace/db";
import { logger } from "./logger";

type AuditAction =
  | "record_uploaded"
  | "record_viewed"
  | "record_downloaded"
  | "record_deleted"
  | "permission_granted"
  | "permission_revoked"
  | "access_requested"
  | "user_registered"
  | "user_logged_in"
  | "wallet_connected"
  | "blockchain_verified";

type AuditEntityType = "record" | "permission" | "user" | "blockchain";

export async function createAuditLog(params: {
  userId: number;
  action: AuditAction;
  entityType: AuditEntityType;
  entityId?: number;
  targetUserId?: number;
  metadata?: string;
  ipAddress?: string;
}): Promise<void> {
  try {
    await db.insert(auditLogsTable).values({
      userId: params.userId,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId ?? null,
      targetUserId: params.targetUserId ?? null,
      metadata: params.metadata ?? null,
      ipAddress: params.ipAddress ?? null,
    });
  } catch (err) {
    logger.error({ err }, "Failed to create audit log");
  }
}
