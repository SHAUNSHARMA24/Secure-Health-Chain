import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import recordsRouter from "./records";
import permissionsRouter from "./permissions";
import auditRouter from "./audit";
import dashboardRouter from "./dashboard";
import doctorsRouter from "./doctors";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(recordsRouter);
router.use(permissionsRouter);
router.use(auditRouter);
router.use(dashboardRouter);
router.use(doctorsRouter);

export default router;
