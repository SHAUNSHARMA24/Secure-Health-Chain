import { Router, type IRouter } from "express";
import { db, medicalRecordsTable, permissionsTable, auditLogsTable, usersTable } from "@workspace/db";
import { eq, count, desc, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

// GET /dashboard/stats
router.get("/dashboard/stats", requireAuth, async (req, res): Promise<void> => {
  const user = req.user!;

  if (user.role === "patient") {
    const [totalRecordsResult] = await db
      .select({ value: count() })
      .from(medicalRecordsTable)
      .where(eq(medicalRecordsTable.patientId, user.userId));

    const [activePermsResult] = await db
      .select({ value: count() })
      .from(permissionsTable)
      .where(and(
        eq(permissionsTable.patientId, user.userId),
        eq(permissionsTable.isActive, true)
      ));

    const [totalAuditResult] = await db
      .select({ value: count() })
      .from(auditLogsTable)
      .where(eq(auditLogsTable.userId, user.userId));

    const allRecords = await db
      .select({ recordType: medicalRecordsTable.recordType })
      .from(medicalRecordsTable)
      .where(eq(medicalRecordsTable.patientId, user.userId));

    const typeCounts: Record<string, number> = {};
    for (const r of allRecords) {
      typeCounts[r.recordType] = (typeCounts[r.recordType] ?? 0) + 1;
    }
    const recordsByType = Object.entries(typeCounts).map(([type, cnt]) => ({ type, count: cnt }));

    const authorizedDoctorRows = await db
      .select({ doctorId: permissionsTable.doctorId })
      .from(permissionsTable)
      .where(and(
        eq(permissionsTable.patientId, user.userId),
        eq(permissionsTable.isActive, true)
      ));
    const uniqueDoctors = new Set(authorizedDoctorRows.map((p) => p.doctorId)).size;

    res.json({
      totalRecords: totalRecordsResult?.value ?? 0,
      activePermissions: activePermsResult?.value ?? 0,
      totalAuditEvents: totalAuditResult?.value ?? 0,
      recordsByType,
      recentRecordsCount: Math.min(Number(totalRecordsResult?.value ?? 0), 5),
      authorizedDoctors: uniqueDoctors,
      totalPatients: 0,
    });
  } else {
    // Doctor stats
    const authorizedPatientRows = await db
      .select({ patientId: permissionsTable.patientId })
      .from(permissionsTable)
      .where(and(
        eq(permissionsTable.doctorId, user.userId),
        eq(permissionsTable.isActive, true)
      ));
    const uniquePatients = new Set(authorizedPatientRows.map((p) => p.patientId)).size;

    const [activePermsResult] = await db
      .select({ value: count() })
      .from(permissionsTable)
      .where(and(
        eq(permissionsTable.doctorId, user.userId),
        eq(permissionsTable.isActive, true)
      ));

    const [totalAuditResult] = await db
      .select({ value: count() })
      .from(auditLogsTable)
      .where(eq(auditLogsTable.userId, user.userId));

    res.json({
      totalRecords: 0,
      activePermissions: activePermsResult?.value ?? 0,
      totalAuditEvents: totalAuditResult?.value ?? 0,
      recordsByType: [],
      recentRecordsCount: 0,
      authorizedDoctors: 0,
      totalPatients: uniquePatients,
    });
  }
});

// GET /dashboard/recent-activity
router.get("/dashboard/recent-activity", requireAuth, async (req, res): Promise<void> => {
  const logs = await db
    .select({
      id: auditLogsTable.id,
      userId: auditLogsTable.userId,
      targetUserId: auditLogsTable.targetUserId,
      action: auditLogsTable.action,
      entityType: auditLogsTable.entityType,
      entityId: auditLogsTable.entityId,
      metadata: auditLogsTable.metadata,
      ipAddress: auditLogsTable.ipAddress,
      createdAt: auditLogsTable.createdAt,
    })
    .from(auditLogsTable)
    .where(eq(auditLogsTable.userId, req.user!.userId))
    .orderBy(desc(auditLogsTable.createdAt))
    .limit(10);

  const enriched = await Promise.all(
    logs.map(async (log) => {
      const [actor] = await db
        .select({ name: usersTable.name })
        .from(usersTable)
        .where(eq(usersTable.id, log.userId));

      let targetName: string | null = null;
      if (log.targetUserId) {
        const [target] = await db
          .select({ name: usersTable.name })
          .from(usersTable)
          .where(eq(usersTable.id, log.targetUserId));
        targetName = target?.name ?? null;
      }

      return { ...log, actorName: actor?.name ?? null, targetName };
    })
  );

  res.json(enriched);
});

export default router;
