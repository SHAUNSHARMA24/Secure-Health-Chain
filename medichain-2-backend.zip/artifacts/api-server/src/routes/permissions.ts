import { Router, type IRouter } from "express";
import { db, permissionsTable, usersTable, medicalRecordsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { GrantPermissionBody, RevokePermissionParams } from "@workspace/api-zod";
import { requireAuth, requireRole } from "../middlewares/auth";
import { createAuditLog } from "../lib/audit";

const router: IRouter = Router();

// GET /permissions
router.get("/permissions", requireAuth, requireRole("patient"), async (req, res): Promise<void> => {
  const rows = await db
    .select({
      id: permissionsTable.id,
      patientId: permissionsTable.patientId,
      doctorId: permissionsTable.doctorId,
      recordId: permissionsTable.recordId,
      isActive: permissionsTable.isActive,
      grantedAt: permissionsTable.grantedAt,
      revokedAt: permissionsTable.revokedAt,
    })
    .from(permissionsTable)
    .where(eq(permissionsTable.patientId, req.user!.userId));

  // Enrich with doctor and record info
  const enriched = await Promise.all(
    rows.map(async (perm) => {
      const [doctor] = await db
        .select({ name: usersTable.name, email: usersTable.email })
        .from(usersTable)
        .where(eq(usersTable.id, perm.doctorId));

      const [record] = await db
        .select({ title: medicalRecordsTable.title })
        .from(medicalRecordsTable)
        .where(eq(medicalRecordsTable.id, perm.recordId));

      return {
        ...perm,
        doctorName: doctor?.name ?? null,
        doctorEmail: doctor?.email ?? null,
        recordTitle: record?.title ?? null,
      };
    })
  );

  res.json(enriched);
});

// POST /permissions
router.post("/permissions", requireAuth, requireRole("patient"), async (req, res): Promise<void> => {
  const parsed = GrantPermissionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { doctorId, recordId } = parsed.data;

  // Verify record belongs to patient
  const [record] = await db
    .select({ id: medicalRecordsTable.id, patientId: medicalRecordsTable.patientId, title: medicalRecordsTable.title })
    .from(medicalRecordsTable)
    .where(eq(medicalRecordsTable.id, recordId));

  if (!record || record.patientId !== req.user!.userId) {
    res.status(403).json({ error: "Record not found or not yours" });
    return;
  }

  // Verify doctor exists
  const [doctor] = await db
    .select({ id: usersTable.id, role: usersTable.role, name: usersTable.name, email: usersTable.email })
    .from(usersTable)
    .where(eq(usersTable.id, doctorId));

  if (!doctor || doctor.role !== "doctor") {
    res.status(400).json({ error: "Doctor not found" });
    return;
  }

  // Check for existing active permission
  const [existing] = await db
    .select({ id: permissionsTable.id })
    .from(permissionsTable)
    .where(
      and(
        eq(permissionsTable.patientId, req.user!.userId),
        eq(permissionsTable.doctorId, doctorId),
        eq(permissionsTable.recordId, recordId),
        eq(permissionsTable.isActive, true)
      )
    );

  if (existing) {
    res.status(400).json({ error: "Permission already granted" });
    return;
  }

  const [perm] = await db
    .insert(permissionsTable)
    .values({
      patientId: req.user!.userId,
      doctorId,
      recordId,
      isActive: true,
    })
    .returning();

  await createAuditLog({
    userId: req.user!.userId,
    targetUserId: doctorId,
    action: "permission_granted",
    entityType: "permission",
    entityId: perm.id,
    metadata: JSON.stringify({ doctorName: doctor.name, recordTitle: record.title }),
    ipAddress: req.ip,
  });

  res.status(201).json({
    ...perm,
    doctorName: doctor.name,
    doctorEmail: doctor.email,
    recordTitle: record.title,
  });
});

// PATCH /permissions/:id/revoke
router.patch("/permissions/:id/revoke", requireAuth, requireRole("patient"), async (req, res): Promise<void> => {
  const params = RevokePermissionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [perm] = await db
    .select()
    .from(permissionsTable)
    .where(eq(permissionsTable.id, params.data.id));

  if (!perm) {
    res.status(404).json({ error: "Permission not found" });
    return;
  }

  if (perm.patientId !== req.user!.userId) {
    res.status(403).json({ error: "Not your permission" });
    return;
  }

  const [revoked] = await db
    .update(permissionsTable)
    .set({ isActive: false, revokedAt: new Date() })
    .where(eq(permissionsTable.id, perm.id))
    .returning();

  const [doctor] = await db
    .select({ name: usersTable.name, email: usersTable.email })
    .from(usersTable)
    .where(eq(usersTable.id, perm.doctorId));

  const [record] = await db
    .select({ title: medicalRecordsTable.title })
    .from(medicalRecordsTable)
    .where(eq(medicalRecordsTable.id, perm.recordId));

  await createAuditLog({
    userId: req.user!.userId,
    targetUserId: perm.doctorId,
    action: "permission_revoked",
    entityType: "permission",
    entityId: perm.id,
    metadata: JSON.stringify({ doctorName: doctor?.name, recordTitle: record?.title }),
    ipAddress: req.ip,
  });

  res.json({
    ...revoked,
    doctorName: doctor?.name ?? null,
    doctorEmail: doctor?.email ?? null,
    recordTitle: record?.title ?? null,
  });
});

export default router;
