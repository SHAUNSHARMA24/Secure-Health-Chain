import { Router, type IRouter } from "express";
import { db, auditLogsTable, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { ListAuditLogsQueryParams } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

// GET /audit
router.get("/audit", requireAuth, async (req, res): Promise<void> => {
  const qp = ListAuditLogsQueryParams.safeParse(req.query);
  const limit = qp.success && qp.data.limit ? Number(qp.data.limit) : 50;

  const logs = await db
    .select({
      id: auditLogsTable.id,
      userId: auditLogsTable.userId,
      targetUserId: auditLogsTable.targetUserId,
      action: auditLogsTable.action,
      entityType: auditLogsTable.entityType,
      entityId: auditLogsTable.entityId,
      metadata: auditLogsTable.metadata,
      ipAddress: auditLogsTable.ipAddress,
      createdAt: auditLogsTable.createdAt,
    })
    .from(auditLogsTable)
    .where(eq(auditLogsTable.userId, req.user!.userId))
    .orderBy(desc(auditLogsTable.createdAt))
    .limit(Math.min(limit, 200));

  // Enrich with actor/target names
  const enriched = await Promise.all(
    logs.map(async (log) => {
      const [actor] = await db
        .select({ name: usersTable.name })
        .from(usersTable)
        .where(eq(usersTable.id, log.userId));

      let targetName: string | null = null;
      if (log.targetUserId) {
        const [target] = await db
          .select({ name: usersTable.name })
          .from(usersTable)
          .where(eq(usersTable.id, log.targetUserId));
        targetName = target?.name ?? null;
      }

      return {
        ...log,
        actorName: actor?.name ?? null,
        targetName,
      };
    })
  );

  res.json(enriched);
});

export default router;
