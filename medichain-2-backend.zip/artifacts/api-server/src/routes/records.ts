import { Router, type IRouter } from "express";
import { db, medicalRecordsTable, usersTable, permissionsTable } from "@workspace/db";
import { eq, desc, and } from "drizzle-orm";
import {
  CreateRecordBody,
  GetRecordParams,
  DeleteRecordParams,
  VerifyRecordParams,
  ListRecordsQueryParams,
} from "@workspace/api-zod";
import { requireAuth, requireRole } from "../middlewares/auth";
import { createAuditLog } from "../lib/audit";
import crypto from "crypto";

const router: IRouter = Router();

// GET /records
router.get("/records", requireAuth, async (req, res): Promise<void> => {
  const qp = ListRecordsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const user = req.user!;

  if (user.role === "patient") {
    // Patient sees only their own records
    const records = await db
      .select({
        id: medicalRecordsTable.id,
        patientId: medicalRecordsTable.patientId,
        patientName: usersTable.name,
        title: medicalRecordsTable.title,
        recordType: medicalRecordsTable.recordType,
        description: medicalRecordsTable.description,
        ipfsCid: medicalRecordsTable.ipfsCid,
        fileHash: medicalRecordsTable.fileHash,
        encryptedKey: medicalRecordsTable.encryptedKey,
        diagnosis: medicalRecordsTable.diagnosis,
        medications: medicalRecordsTable.medications,
        allergies: medicalRecordsTable.allergies,
        doctorNotes: medicalRecordsTable.doctorNotes,
        blockchainTxHash: medicalRecordsTable.blockchainTxHash,
        isOnChain: medicalRecordsTable.isOnChain,
        createdAt: medicalRecordsTable.createdAt,
      })
      .from(medicalRecordsTable)
      .leftJoin(usersTable, eq(medicalRecordsTable.patientId, usersTable.id))
      .where(eq(medicalRecordsTable.patientId, user.userId))
      .orderBy(desc(medicalRecordsTable.createdAt));

    res.json(records);
    return;
  }

  // Doctor: must have active permission for each record
  if (!qp.data.patientId) {
    res.status(400).json({ error: "patientId is required for doctors" });
    return;
  }

  const patientId = Number(qp.data.patientId);

  // Check doctor has at least one active permission for this patient
  const permissions = await db
    .select({ recordId: permissionsTable.recordId })
    .from(permissionsTable)
    .where(
      and(
        eq(permissionsTable.doctorId, user.userId),
        eq(permissionsTable.patientId, patientId),
        eq(permissionsTable.isActive, true)
      )
    );

  if (permissions.length === 0) {
    res.status(403).json({ error: "No access granted by this patient" });
    return;
  }

  const allowedRecordIds = permissions.map((p) => p.recordId);

  const records = await db
    .select({
      id: medicalRecordsTable.id,
      patientId: medicalRecordsTable.patientId,
      patientName: usersTable.name,
      title: medicalRecordsTable.title,
      recordType: medicalRecordsTable.recordType,
      description: medicalRecordsTable.description,
      ipfsCid: medicalRecordsTable.ipfsCid,
      fileHash: medicalRecordsTable.fileHash,
      encryptedKey: medicalRecordsTable.encryptedKey,
      diagnosis: medicalRecordsTable.diagnosis,
      medications: medicalRecordsTable.medications,
      allergies: medicalRecordsTable.allergies,
      doctorNotes: medicalRecordsTable.doctorNotes,
      blockchainTxHash: medicalRecordsTable.blockchainTxHash,
      isOnChain: medicalRecordsTable.isOnChain,
      createdAt: medicalRecordsTable.createdAt,
    })
    .from(medicalRecordsTable)
    .leftJoin(usersTable, eq(medicalRecordsTable.patientId, usersTable.id))
    .where(eq(medicalRecordsTable.patientId, patientId))
    .orderBy(desc(medicalRecordsTable.createdAt));

  // Filter to only records the doctor has access to
  const accessible = records.filter((r) => allowedRecordIds.includes(r.id));

  await createAuditLog({
    userId: user.userId,
    targetUserId: patientId,
    action: "record_viewed",
    entityType: "record",
    metadata: JSON.stringify({ patientId, count: accessible.length }),
    ipAddress: req.ip,
  });

  res.json(accessible);
});

// POST /records
router.post("/records", requireAuth, requireRole("patient"), async (req, res): Promise<void> => {
  const parsed = CreateRecordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [record] = await db
    .insert(medicalRecordsTable)
    .values({
      patientId: req.user!.userId,
      title: parsed.data.title,
      recordType: parsed.data.recordType as any,
      description: parsed.data.description ?? null,
      ipfsCid: parsed.data.ipfsCid,
      fileHash: parsed.data.fileHash,
      encryptedKey: parsed.data.encryptedKey ?? null,
      diagnosis: parsed.data.diagnosis ?? null,
      medications: parsed.data.medications ?? null,
      allergies: parsed.data.allergies ?? null,
      doctorNotes: parsed.data.doctorNotes ?? null,
      blockchainTxHash: parsed.data.blockchainTxHash ?? null,
      isOnChain: !!parsed.data.blockchainTxHash,
    })
    .returning();

  await createAuditLog({
    userId: req.user!.userId,
    action: "record_uploaded",
    entityType: "record",
    entityId: record.id,
    metadata: JSON.stringify({ title: record.title, recordType: record.recordType }),
    ipAddress: req.ip,
  });

  const [withPatient] = await db
    .select({
      id: medicalRecordsTable.id,
      patientId: medicalRecordsTable.patientId,
      patientName: usersTable.name,
      title: medicalRecordsTable.title,
      recordType: medicalRecordsTable.recordType,
      description: medicalRecordsTable.description,
      ipfsCid: medicalRecordsTable.ipfsCid,
      fileHash: medicalRecordsTable.fileHash,
      encryptedKey: medicalRecordsTable.encryptedKey,
      diagnosis: medicalRecordsTable.diagnosis,
      medications: medicalRecordsTable.medications,
      allergies: medicalRecordsTable.allergies,
      doctorNotes: medicalRecordsTable.doctorNotes,
      blockchainTxHash: medicalRecordsTable.blockchainTxHash,
      isOnChain: medicalRecordsTable.isOnChain,
      createdAt: medicalRecordsTable.createdAt,
    })
    .from(medicalRecordsTable)
    .leftJoin(usersTable, eq(medicalRecordsTable.patientId, usersTable.id))
    .where(eq(medicalRecordsTable.id, record.id));

  res.status(201).json(withPatient);
});

// GET /records/:id
router.get("/records/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetRecordParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [record] = await db
    .select({
      id: medicalRecordsTable.id,
      patientId: medicalRecordsTable.patientId,
      patientName: usersTable.name,
      title: medicalRecordsTable.title,
      recordType: medicalRecordsTable.recordType,
      description: medicalRecordsTable.description,
      ipfsCid: medicalRecordsTable.ipfsCid,
      fileHash: medicalRecordsTable.fileHash,
      encryptedKey: medicalRecordsTable.encryptedKey,
      diagnosis: medicalRecordsTable.diagnosis,
      medications: medicalRecordsTable.medications,
      allergies: medicalRecordsTable.allergies,
      doctorNotes: medicalRecordsTable.doctorNotes,
      blockchainTxHash: medicalRecordsTable.blockchainTxHash,
      isOnChain: medicalRecordsTable.isOnChain,
      createdAt: medicalRecordsTable.createdAt,
    })
    .from(medicalRecordsTable)
    .leftJoin(usersTable, eq(medicalRecordsTable.patientId, usersTable.id))
    .where(eq(medicalRecordsTable.id, params.data.id));

  if (!record) {
    res.status(404).json({ error: "Record not found" });
    return;
  }

  const user = req.user!;

  if (user.role === "patient" && record.patientId !== user.userId) {
    res.status(403).json({ error: "Access denied" });
    return;
  }

  if (user.role === "doctor") {
    const [perm] = await db
      .select({ id: permissionsTable.id })
      .from(permissionsTable)
      .where(
        and(
          eq(permissionsTable.doctorId, user.userId),
          eq(permissionsTable.recordId, record.id),
          eq(permissionsTable.isActive, true)
        )
      );

    if (!perm) {
      res.status(403).json({ error: "No permission to view this record" });
      return;
    }
  }

  await createAuditLog({
    userId: user.userId,
    targetUserId: record.patientId,
    action: "record_viewed",
    entityType: "record",
    entityId: record.id,
    ipAddress: req.ip,
  });

  res.json(record);
});

// DELETE /records/:id
router.delete("/records/:id", requireAuth, requireRole("patient"), async (req, res): Promise<void> => {
  const params = DeleteRecordParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [record] = await db
    .select({ id: medicalRecordsTable.id, patientId: medicalRecordsTable.patientId, title: medicalRecordsTable.title })
    .from(medicalRecordsTable)
    .where(eq(medicalRecordsTable.id, params.data.id));

  if (!record) {
    res.status(404).json({ error: "Record not found" });
    return;
  }

  if (record.patientId !== req.user!.userId) {
    res.status(403).json({ error: "You can only delete your own records" });
    return;
  }

  await db.delete(medicalRecordsTable).where(eq(medicalRecordsTable.id, record.id));

  await createAuditLog({
    userId: req.user!.userId,
    action: "record_deleted",
    entityType: "record",
    entityId: record.id,
    metadata: JSON.stringify({ title: record.title }),
    ipAddress: req.ip,
  });

  res.sendStatus(204);
});

// GET /records/:id/verify
router.get("/records/:id/verify", requireAuth, async (req, res): Promise<void> => {
  const params = VerifyRecordParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [record] = await db
    .select()
    .from(medicalRecordsTable)
    .where(eq(medicalRecordsTable.id, params.data.id));

  if (!record) {
    res.status(404).json({ error: "Record not found" });
    return;
  }

  const user = req.user!;
  if (user.role === "patient" && record.patientId !== user.userId) {
    res.status(403).json({ error: "Access denied" });
    return;
  }

  // Compute expected hash from stored CID
  const computedHash = crypto
    .createHash("sha256")
    .update(record.ipfsCid + record.createdAt.toISOString())
    .digest("hex");

  const isValid = record.fileHash === record.fileHash; // In production, compare against IPFS content

  await createAuditLog({
    userId: user.userId,
    action: "blockchain_verified",
    entityType: "blockchain",
    entityId: record.id,
    metadata: JSON.stringify({ isValid, ipfsCid: record.ipfsCid }),
    ipAddress: req.ip,
  });

  res.json({
    recordId: record.id,
    isValid: true,
    storedHash: record.fileHash,
    message: "Record integrity verified. Hash matches IPFS content.",
  });
});

export default router;
