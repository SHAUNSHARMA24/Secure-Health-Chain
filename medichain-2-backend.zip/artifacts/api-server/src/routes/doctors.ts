import { Router, type IRouter } from "express";
import { db, usersTable, permissionsTable, medicalRecordsTable } from "@workspace/db";
import { eq, count, and } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";

const router: IRouter = Router();

// GET /doctors
router.get("/doctors", requireAuth, async (req, res): Promise<void> => {
  const doctors = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      specialization: usersTable.specialization,
      licenseNumber: usersTable.licenseNumber,
      isVerified: usersTable.isVerified,
      walletAddress: usersTable.walletAddress,
    })
    .from(usersTable)
    .where(eq(usersTable.role, "doctor"));

  res.json(doctors);
});

// GET /doctors/my-patients
router.get("/doctors/my-patients", requireAuth, requireRole("doctor"), async (req, res): Promise<void> => {
  const perms = await db
    .select({ patientId: permissionsTable.patientId, grantedAt: permissionsTable.grantedAt })
    .from(permissionsTable)
    .where(
      and(
        eq(permissionsTable.doctorId, req.user!.userId),
        eq(permissionsTable.isActive, true)
      )
    );

  const uniquePatients = new Map<number, Date>();
  for (const p of perms) {
    if (!uniquePatients.has(p.patientId) || uniquePatients.get(p.patientId)! < p.grantedAt) {
      uniquePatients.set(p.patientId, p.grantedAt);
    }
  }

  const patients = await Promise.all(
    Array.from(uniquePatients.entries()).map(async ([patientId, grantedAt]) => {
      const [user] = await db
        .select({
          id: usersTable.id,
          name: usersTable.name,
          email: usersTable.email,
          bloodGroup: usersTable.bloodGroup,
        })
        .from(usersTable)
        .where(eq(usersTable.id, patientId));

      const [recordCount] = await db
        .select({ value: count() })
        .from(permissionsTable)
        .where(
          and(
            eq(permissionsTable.doctorId, req.user!.userId),
            eq(permissionsTable.patientId, patientId),
            eq(permissionsTable.isActive, true)
          )
        );

      return {
        id: user?.id ?? patientId,
        name: user?.name ?? "Unknown",
        email: user?.email ?? "",
        bloodGroup: user?.bloodGroup ?? null,
        recordCount: recordCount?.value ?? 0,
        permissionGrantedAt: grantedAt.toISOString(),
      };
    })
  );

  res.json(patients);
});

export default router;
