import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { UpdateProfileBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";
import { createAuditLog } from "../lib/audit";

const router: IRouter = Router();

// PATCH /users/profile
router.patch("/users/profile", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Record<string, unknown> = {};
  const data = parsed.data;

  if (data.name !== undefined) updates.name = data.name;
  if (data.walletAddress !== undefined) updates.walletAddress = data.walletAddress;
  if (data.bloodGroup !== undefined) updates.bloodGroup = data.bloodGroup;
  if (data.dateOfBirth !== undefined) updates.dateOfBirth = data.dateOfBirth;
  if (data.gender !== undefined) updates.gender = data.gender;
  if (data.phone !== undefined) updates.phone = data.phone;
  if (data.specialization !== undefined) updates.specialization = data.specialization;

  if (data.walletAddress) {
    await createAuditLog({
      userId: req.user!.userId,
      action: "wallet_connected",
      entityType: "user",
      entityId: req.user!.userId,
      metadata: JSON.stringify({ walletAddress: data.walletAddress }),
      ipAddress: req.ip,
    });
  }

  const [updated] = await db
    .update(usersTable)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(usersTable.id, req.user!.userId))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const { passwordHash: _ph, ...safeUser } = updated;
  res.json(safeUser);
});

export default router;
